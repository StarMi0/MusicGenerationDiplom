# Keras Music Generation
Music generation with Keras and LSTM

## Requirements

### Python
1. Jupyter Notebook
2. Python3.7

### Packages
```
mido==1.2.9
tensorflow==1.14.0
Keras==2.1.2
sklearn==0.0
numpy==1.17.3
```
Check [Jupyter Notebook](/Music%20gerenation%20with%20Keras%20and%20TF.ipynb)
